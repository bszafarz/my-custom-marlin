# Contributing Changes

- Make a fork of this repository under your account.
- Use Clone or Download to open the repo on your computer.
- Use Git or Guthub Desktop to checkout the `import-2.0.x` branch.
- Add new configurations and/or make changes to existing ones.
- Commit your changes and push them to your fork.
- Submit a Pull Request to the `import-2.0.x` branch.
